from django.shortcuts import render
from tiendas.models import Tienda

def tienda_principal(request):
    
    return render(request, 'tienda_principal.html', {})

def tienda_index(request):
    tiendas = Tienda.objects.all()
    context = {
        'tiendas': tiendas
    }
    return render(request, 'tienda_index.html', context)
    
def tienda_detail(request, pk):
    tienda = Tienda.objects.get(pk=pk)
    context = {
        'tienda': tienda
    }
    return render(request, 'tienda_detail.html', context)

def tienda_contacto(request):
    
    return render(request, 'tienda_contacto.html', {})