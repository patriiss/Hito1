from django.db import models

class Tienda(models.Model):
    descripcion = models.CharField(max_length=100)
    caracteristicas = models.TextField()
    precio = models.CharField(max_length=20)
    imagen = models.FilePathField(path="/img")
