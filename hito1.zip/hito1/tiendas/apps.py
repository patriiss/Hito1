from django.apps import AppConfig


class TiendasConfig(AppConfig):
    name = 'tiendas'
